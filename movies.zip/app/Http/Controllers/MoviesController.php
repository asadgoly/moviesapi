<?php

namespace App\Http\Controllers;

use App\Models\Movies;
use App\Http\Requests\StoreMoviesRequest;
use App\Http\Requests\UpdateMoviesRequest;
use Illuminate\Http\Request;

class MoviesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //Here it will show and serve my movies data
        $movies = Movies::all();
        // It mean I need to serve and show all moves
        // I have stored data in $movies variable
        return $movies;
        // lets test our rotues
    }

        /**
     * Delete a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    // lets make changes
    public function delete($id)
    {
        // now I will delete record by using id
        // we will get id from user and then delete record..
        $movies = Movies::find($id);
        // find function will find movies by id and we will do the delete op
        $result = $movies->delete();
        // I have restore the result in result variable.
        return ["result"=>"Movies deleted."];
        // guys this last line might be complex and difficult
        // it is just showing user that we have deleted record.
        // Now we will create rotues in api.php file..
    }

// I have copied the index route and now I will modfiy it
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function post_movies(Request $req)
    {
        // Now I will post movies...
        $movies = new Movies;
        // Now I will get data data from users
        $movies->name = $req->name;
        $movies->language = $req->language ;
        $movies->year = $req->year;
        // Now I will save data to database...
        // sorry I made a mistake.
        //Now I will save it to database.
        $movies->save();
        // now I will return to user
        return $movies;
        // Now I will create the post route..
    }

    // I will create single entry here...

     /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function single($id)
    {
        // Here we will get single entry/movies
        $movies = Movies::find($id);
        // now we will display it to user
        return $movies;
        // now we will create our single entry route in api.php file.
    }

/**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function update(Request $req, $id)
    {
        $movies = Movies::find($id);
        $movies->name = $req->name;
        $movies->language = $req->language;
        $movies->year = $req->year;
        $movies-> save();
        // now we will show the updated movies to useers
        return $movies;
        // now we will create a create for update.

    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreMoviesRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreMoviesRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Movies  $movies
     * @return \Illuminate\Http\Response
     */
    public function show(Movies $movies)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Movies  $movies
     * @return \Illuminate\Http\Response
     */
    public function edit(Movies $movies)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateMoviesRequest  $request
     * @param  \App\Models\Movies  $movies
     * @return \Illuminate\Http\Response
     */
// remove duplicate update function


    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Movies  $movies
     * @return \Illuminate\Http\Response
     */
    public function destroy(Movies $movies)
    {
        //
    }
}
