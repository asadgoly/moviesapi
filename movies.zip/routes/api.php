<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MoviesController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});


Route::get('/',[MoviesController::class,'index']);
Route::delete('/{id}',[MoviesController::class,'delete']);
// I have change to delete method
// {id} is added to get id from user
// delete function is added to be called
// lets test in thunder client.... 
// api testing software...
Route::post('/',[MoviesController::class,'post_movies']);
/// lets test our rotues
Route::get('/{id}',[MoviesController::class,'single']);
// rotue for updating movies
Route::post('/{id}',[MoviesController::class,'update']);
// lets test it on thunder client...